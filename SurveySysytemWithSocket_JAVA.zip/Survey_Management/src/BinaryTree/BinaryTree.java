//Source:  http://www.newthinktank.com/2013/03/binary-tree-in-java/
// New Think Tank

package BinaryTree;

public class BinaryTree {
	public BNode root;
	public String treeToText;	//String to show in the BTree textArea

	public void addNode(int key, String name)
	{
		BNode newNode = new BNode(key, name);		// Create a new Node and initialize it

		if (root == null) 		// If there is no root this becomes root
		{
			root = newNode;
		} else
		{
			BNode focusNode = root;		// Set root as the Node we will start with as we traverse the tree

			BNode parent;		// Future parent for our new Node

			while (true)
			{
				parent = focusNode;		// root is the top parent so we start there

				if (key < focusNode.key) 		// Check if the new node should go on the left side of the parent node
				{
					focusNode = focusNode.leftChild;		// Switch focus to the left child

					if (focusNode == null) 		// If the left child has no children
					{
						parent.leftChild = newNode;		// then place the new node on the left of it
						return; 	// All Done

					}
				} else
				{
					focusNode = focusNode.rightChild;		// If we get here put the node on the right

					if (focusNode == null) 		// If the right child has no children
					{

						parent.rightChild = newNode;		// then place the new node on the right of it
						return; 	// All Done
					}
				}
			}
		}
	}

	// All nodes are visited in ascending order
	// Recursion is used to go to one node and then go to its child nodes and so forth

	public String inOrderTraverseTree(BNode focusNode) {

		if (focusNode != null) {

			preOrderTraverseTree(focusNode.leftChild);

			treeToText = treeToText + focusNode.key + " - " + focusNode.name + ", ";

			preOrderTraverseTree(focusNode.rightChild);
		}
		return  treeToText;
	}

	public String preOrderTraverseTree(BNode focusNode) {

		if (focusNode != null) {

			treeToText = treeToText + focusNode.key + " - " + focusNode.name + ", ";

			preOrderTraverseTree(focusNode.leftChild);
			preOrderTraverseTree(focusNode.rightChild);

		}
		return  treeToText;
	}

	public String postOrderTraverseTree(BNode focusNode) {

		if (focusNode != null) {

			preOrderTraverseTree(focusNode.leftChild);
			preOrderTraverseTree(focusNode.rightChild);

			treeToText = treeToText + focusNode.key + " - " + focusNode.name + ", ";
		}
		return  treeToText;
	}

	public BNode findNode(int key) 	// Start at the top of the tree
	{
		BNode focusNode = root;

		while (focusNode.key != key) 		// While we haven't found the Node, keep looking
		{
			if (key < focusNode.key) 	// If we should search to the left
			{
				focusNode = focusNode.leftChild;	// Shift the focus Node to the left child
			} else
			{
				focusNode = focusNode.rightChild;	// Shift the focus Node to the right child
			}

			if (focusNode == null)		// The node wasn't found
				return null;
		}
		return focusNode;
	}
}

class BNode
{
	int key;
	String name;
	BNode leftChild;
	BNode rightChild;
	BNode(int key, String name)
	{
		this.key = key;
		this.name = name;
	}

//	public String toString()
//	{
//
//		//return name + " has the key " + key;
//
//		/*
//		 * return name + " has the key " + key + "\nLeft Child: " + leftChild +
//		 * "\nRight Child: " + rightChild + "\n";
//		 */
//		if(key==0 && name==null)
//		{
//			// list is empty, only header DList.Node
//			return "List Empty";
//		}
//		return "0";
//	}
}
